from .lightning_base_model import BaseModel
from .gpt2 import GPT2
from .ols import CnnKF